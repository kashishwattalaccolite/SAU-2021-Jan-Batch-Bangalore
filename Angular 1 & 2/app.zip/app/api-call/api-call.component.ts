import { Component, OnInit } from '@angular/core';
import { httpservice } from '../services/http.service';

@Component({
  selector: 'app-api-call',
  templateUrl: './api-call.component.html',
  styleUrls: ['./api-call.component.scss']
})
export class ApiCallComponent implements OnInit {

  constructor(private _msgService:httpservice) { }
  products=[];
  ngOnInit(): void {
    this._msgService.product().subscribe(productData=>this.products=productData);
  }
 

}
