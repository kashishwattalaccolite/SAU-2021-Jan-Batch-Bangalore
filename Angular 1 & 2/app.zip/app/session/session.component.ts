import { Component, OnInit } from '@angular/core';
import { sessionModel } from './sessionModel/sessionModel';


@Component({
  selector: 'app-session',
  templateUrl: './session.component.html',
  styleUrls: ['./session.component.scss']
})
export class SessionComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }

  sessions: sessionModel[] = [
    {
      name: 'VCS',
      trainer: 'Devansh',
      date: '06/01'
    },
    {
      name: 'RDBMS',
      trainer: 'Sivagami',
      date:'07/01'
    },
    {
      name: 'NoSQL',
      trainer: 'Abhishek',
      date: '08/01'
    },
    {
      name: 'HTML',
      trainer: 'Vigneshwar',
      date: '08/01'
    },
    {
      name: 'Javascript-1',
      trainer: 'Anushree',
      date: '11/01'
    },
    {
      name: 'Javascript-2',
      trainer: 'Pranay',
      date: '11/01'
    },
    {
      name: 'Angular-1',
      trainer: 'Sharanya',
      date: '12/01'
    },
    {
      name: 'Angular-2',
      trainer: 'Pritam',
      date: '12/01'
    }
  ]
  selectedSession: sessionModel= new sessionModel();

  

  onSelect(session : sessionModel)
  {
    this.selectedSession=session;
  }
  addSession() {
    var n=(<HTMLInputElement>document.getElementById("sessname")).value;
    var d=(<HTMLInputElement>document.getElementById("sessdate")).value;
    var t=(<HTMLInputElement>document.getElementById("sesstrainer")).value;
    

    if (n&&d&&t) {
      this.sessions.push({name:n,trainer:t,date:d});
    }
  }
  delSession(session : sessionModel)
  {
    this.sessions = this.sessions.filter(obj => obj.name != session.name);
  }

}
