export class sessionModel {
    name: string ;
    trainer: string ;
    date: string;
  }