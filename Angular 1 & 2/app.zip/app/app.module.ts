import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SessionComponent } from './session/session.component';
import { HttpClientModule } from '@angular/common/http';
import { ApiCallComponent } from './api-call/api-call.component';
import { RouterModule, Routes } from '@angular/router';


const appRoutes:Routes=[
  {path:' ', component:AppComponent},
  {path:'api-call', component:ApiCallComponent},
  {path:'session', component:SessionComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    SessionComponent,
    ApiCallComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    AppRoutingModule,
    HttpClientModule,
    RouterModule.forRoot(appRoutes)
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
